# Aliases to alter your umask
#
# With these two values of umask, new files and directories will have
# permissions of 775 or 755, respectively.

alias open='umask 002'
alias shut='umask 022'
